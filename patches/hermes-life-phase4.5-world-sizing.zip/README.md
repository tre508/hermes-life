Hermes Life Phase 4.5 — viewport world sizing fix

Fixes Phase 4.4 CSS where `#shell > main` has an auto-sized second grid row and
operations logs expand the row indefinitely. This pushed the centered game canvas
far below the viewport and created a very tall blank world panel.

Installation (after Phase 4.4):
  cd ~/Apps/hermes-life
  unzip -o ~/Downloads/hermes-life-phase4.5-world-sizing.zip
  python3 scripts/install-phase45-world-sizing.py
  ./scripts/start-world.sh

Then hard refresh the frontend. Does not touch backend or world engine.
