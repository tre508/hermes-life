#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -d .venv ]]; then
  python3 -m venv .venv
fi
. .venv/bin/activate
# Install dependencies explicitly during setup, not on every server start.
if ! .venv/bin/python -c 'import hermes_life, uvicorn' >/dev/null 2>&1; then
  echo 'Dependencies missing: run .venv/bin/pip install -e ".[test]"' >&2
  exit 1
fi
exec uvicorn hermes_life.app:create_app --factory --host 127.0.0.1 --port 8766
