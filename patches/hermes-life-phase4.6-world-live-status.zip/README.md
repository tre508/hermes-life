# Hermes Life Phase 4.6 — readable world status

Replaces the low-resolution Phaser narration *display* with a native DOM overlay that renders sharply as the world canvas grows. The live banner shows **confirmed runtime activity** from the existing `/ws/events` pipeline (queued, started, tool use/result, completed, failed), not internal private chain-of-thought. The existing room movement, event stream, task APIs, and chat are unchanged. Phaser renderer uses up to 2x device-pixel resolution to sharpen in-scene text.

## Install

From your Hermes Life root:

```sh
unzip -o ~/Downloads/hermes-life-phase4.6-world-live-status.zip
python3 scripts/install-phase46-world-status.py
```

Restart `./scripts/start-world.sh`, then hard-refresh the browser.

The installer checks required anchors before writing, makes timestamped backups of `main.ts` and the destination CSS if present, and is idempotent. The overlay CSS lives at `frontend/src/phase46-world-status.css`. It requires the existing frontend with Phaser and the Phase 4.5 layout; it does not change the backend.

**Scope limit:** This patch shows live execution steps/tool names **only when emitted** by your backend. It does not provide token-by-token model output, hidden reasoning, or additional Hermes events.
