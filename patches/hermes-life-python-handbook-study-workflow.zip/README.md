# Hermes Life — Chapter-by-chapter Python study workflow

Host-side controller. Requires an indexed Ultimate Python Handbook and the existing SSH VM transport.

```bash
cd ~/Apps/hermes-life
python3 scripts/study-python-handbook.py prepare
python3 scripts/study-python-handbook.py enqueue-next
python3 scripts/study-python-handbook.py status
```

`prepare` reads only heading snippets from the PDF in the isolated VM and creates `study/python-handbook/manifest.json` on the host. It detects clear printed chapter openers; otherwise it explicitly uses 5-page study units rather than guessing chapters. It does not copy the PDF to the host.

`enqueue-next` creates **one** goal through the existing `/api/goals` endpoint. It never starts the next until the preceding one is marked completed in the API. This is deliberately manual between goals; repeat the command after the prior goal finishes. Goals execute under the existing scheduler/VM SSH adapter, not the local host agent. Enable autonomous execution in the Hermes Life UI if disabled.

Each goal reads its assigned pages inside the VM, generates a cited section report and executable examples, runs tests, and submits exact tool-result evidence to the existing technical-memory mechanism. The host technical lessons API is the source of truth for promoted lessons. PDF content remains untrusted reference material; reading a page is not verification.

Reports and tests are saved under `/home/hermes/learning/python-handbook/study/` inside the VM. The controller does not modify your database schema, UI or personality, nor does it claim that unexecuted examples are verified.

**Limitations:** PDF heading detection is heuristic; check the manifest's units. Pages without extractable text need manual examination. Task completion depends on the current autonomous goal scheduler. The controller does not automatically rerun failed study units. `--replace` regenerates the manifest and resets queue metadata; use only when intentional.
