# Hermes Life — Continuous Starship Bridge (Phase 3.10)

A frontend-only replacement for the six isolated room cards. One continuous, Star-Trek-inspired command deck houses six interactive functional stations: Planning (command), Library (science), Studio (engineering), Archive (records), Test Lab (diagnostics), Lounge (rest).

- Existing Phaser event-to-room routing, agent animation, walking state, room selection, tabs, response workspace, host DB and VM integration are preserved.
- The six functional workstations remain distinct destinations; each opens the existing workspace selection panel.
- Procedural pixel art is original and inspired by the *layout idea*, not copied assets from the Pixel Worlds plugin.
- No Hermes Desktop plugin or backend change is required.

Stop the frontend, backup `frontend/src/main.ts` and `frontend/src/style.css`, unzip this patch at the project root, restart `./scripts/start-world.sh`, and force-refresh the browser.

The project version label is unchanged because this is a frontend-scene patch only.
