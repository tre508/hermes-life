# Hermes Life — Python Handbook ingestion

This patch contains **only two host-side scripts**, no backend or UI files. It requires the Knowledge Library foundation (`GET /api/library/sources` and `POST /api/library/sources/{id}/pages`) and the existing isolated SSH VM. The PDF download, extraction, and persistent copy occur in the **VM**; the host pulls JSONL page text over SSH and indexes it through the host-only HTTP API.

## Install and execute (Kubuntu host)

Leave the Hermes Life backend running with `HERMES_LIFE_TRANSPORT=ssh`.

```bash
cd ~/Apps/hermes-life
unzip -o ~/Downloads/hermes-life-python-handbook-ingestion.zip
python3 scripts/ingest-python-handbook.py
```

The script gets the PDF from CodeWithHarry's original repository and saves it to:

`/home/hermes/learning/python-handbook/The Ultimate Python Handbook.pdf`

If `pypdf` is not available in the VM, it creates a **VM-local** Python virtual environment at `/home/hermes/learning/python-handbook/.venv` and installs `pypdf` there. No system Python modifications are needed. The host does not mount the VM disk or expose its local API to the VM.

The host registers the original GitHub file URL with the PDF SHA256 and indexes each page through API batches of 50. Progress prints as batches are ingested. Re-running reuses the downloaded PDF, and replaces indexed page chunks instead of duplicating them.

## Validate

```bash
curl -sS http://127.0.0.1:8766/api/library/sources | python3 -m json.tool
curl -sS 'http://127.0.0.1:8766/api/library/search?q=python+functions' | python3 -m json.tool
```

The importer verifies the number of indexed pages equals the PDF's page count, and reports blank-text pages (if any). It **does not claim comprehension, verify technical statements, run the book's exercises, or promote any text into evidence-backed technical memory**. Those are separate learning and verification workflows. The PDF revision is currently labeled `main` (not a pinned commit); the SHA256 precisely identifies the downloaded bytes.

## Failure handling

The importer checks that the host API exists before starting. If extraction fails, it exits nonzero. Already indexed batches remain safely indexed and the importer can be rerun. Pages containing more than 30,000 extracted characters cause an explicit failure rather than silent truncation. Blank-text PDF pages are included in the count and listed for separate handling (e.g., scanned pages need text extraction via OCR).
