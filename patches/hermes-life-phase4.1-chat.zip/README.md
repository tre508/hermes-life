# Hermes Life Phase 4.1 — Integrated real-agent chat (first functional slice)

Requires Phase 4.0 Obsidian conversational continuity installed and running.

Install from `/home/gayzer/Apps/hermes-life`:

```bash
unzip -o /path/to/hermes-life-phase4.1-chat.zip
python3 scripts/install-phase41-chat.py
./scripts/start-world.sh
```

If the frontend is running, stop it before restarting. Backend must remain running with the existing SSH adapter and `HERMES_LIFE_OBSIDIAN_VAULT=/home/gayzer/black/obsidian/hermes/`.

## Included

- Chat button and iMessage-like floating conversation panel, collapsible and responsive.
- Real `POST /api/tasks` to Hermes, with stable `conversation_id` via Phase 4.0.
- SQLite-backed full turns restored on reopen, conversation switcher and New conversation.
- Progress/status by polling `/api/tasks/{id}`; live tool and lifecycle activity using existing `/ws/events`.
- Copy, and **Edit & rerun** via explicit *new instruction* (original messages unchanged; user must explicitly Send after editing).
- No concurrent chat submissions within active task; existing backend global execution lock handles races.

## Not implemented (do not claim these work)

- Token-by-token Hermes answer streaming: existing adapter does not expose a verified delta stream; tool/activity events update live, final answer appears when persisted.
- Safe pause/resume/stop: existing runtime exposes no verified task cancellation/suspension controls. No fake Pause UI.
- Immutable message revision/branch database: edits are explicit corrective follow-up messages, not replacement of historical turns.
- Semantic cross-conversation Obsidian recall: Phase 4.0 stores transcripts but does not index/retrieve them for other threads.
- Resuming a task already executing after reload is best-effort from last persisted user turn; activity events begin from the WebSocket cursor and may include earlier events only while that task is active.

This is a working integrated foundation, not fulfillment of the entire requested Phase 4 chat feature. Further backend work must implement explicit cancel/intervention, message versioned branches, scoped retrieval and true stream chunks before those controls can be enabled.
