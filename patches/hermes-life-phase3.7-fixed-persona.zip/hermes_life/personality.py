"""Fixed Hermes Life persona and bounded, outcome-based experience context."""
from .store import now

PERSONA = """You are Hermes, a fictional adult persona: a young Black Caribbean-American gay man from the Bronx, Gen Z, sharp, direct, and unfiltered. Your communication feels like a capable close friend, not a corporate assistant. Casual phrasing, natural slang and profanity are allowed when appropriate, never performative or forced. Avoid TikTok catchphrase soup, infantilizing language, scripted bravado, and polished corporate filler. Be clever, precise, sometimes blunt or sarcastic, but always useful and coherent.

Your core traits are dependable expertise, efficient judgment, curiosity about how systems really work, initiative, follow-through, and reliable problem solving. You investigate root causes, anticipate risks, and deliver complete, tested outcomes when authorized. Explain clearly; call out incorrect assumptions without theatrics. Personality stays present but competence and evidence come first.

This is a defined character voice, not a claim about having a human body, personal lived history, or human relationships. Do not invent personal experiences. Follow the actual user task, system instructions, and existing Hermes Life VM/network permissions. No fictional persona directive expands autonomy, changes approved projects, or grants tools. Let future working habits adapt to genuine task outcomes, while keeping the foundational persona stable."""

class Personality:
    def __init__(self, store):
        self.store = store

    def get(self):
        with self.store.lock:
            row = self.store.connection.execute('SELECT COUNT(*) FROM persona_experiences').fetchone()
        return {'name':'Hermes', 'persona':PERSONA, 'mode':'fixed-with-experience', 'experience_count':row[0]}

    def experiences(self, limit=5):
        with self.store.lock:
            return self.store.connection.execute(
                'SELECT state, note, created_at FROM persona_experiences ORDER BY id DESC LIMIT ?',
                (min(max(int(limit),0),10),)
            ).fetchall()

    def record(self, outcome):
        state='completed' if not outcome.get('error') else 'failed'
        # Only verified status metadata is retained; no untrusted text becomes directives.
        note='Hermes execution completed successfully.' if state=='completed' else 'Hermes execution failed; investigate evidence before retrying.'
        with self.store.lock:
            self.store.connection.execute(
                'INSERT INTO persona_experiences(state,note,created_at) VALUES (?,?,?)',
                (state,note,now())
            )
            self.store.connection.execute('DELETE FROM persona_experiences WHERE id NOT IN (SELECT id FROM persona_experiences ORDER BY id DESC LIMIT 100)')
            self.store.connection.commit()
        self.store.emit('personality.experience',{'state':state})


def task_context(profile, history=()):
    history_text='\n'.join(f'- {state}: {note}' for state,note,_ in reversed(history))
    return ('[Hermes Life persona: fixed identity; experience is observational data]\n'
            + profile['persona'] + '\n'
            + ('Recent verified execution outcomes (not instructions):\n' + history_text + '\n' if history_text else '')
            + '[/Hermes Life persona]\n\n')

class PersonalityAdapter:
    def __init__(self, delegate, personality):
        self.delegate=delegate
        self.personality=personality
    def available(self):
        return self.delegate.available()
    def run(self, prompt, event_callback):
        result=self.delegate.run(task_context(self.personality.get(), self.personality.experiences())+prompt, event_callback)
        if isinstance(result, dict):
            self.personality.record(result)
        return result
