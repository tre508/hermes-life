# Hermes Life — fixed persona patch

Applies over the existing Hermes Life Phase 3.7B / walking-world installation.

- Removes the nonfunctional editable personality controls.
- Fixes a single Hermes persona and presents its description in Overview.
- Makes `GET /api/personality` read-only, removes the obsolete PUT and presets endpoints.
- Adds schema version 5 with `persona_experiences`, a bounded record of execution outcomes, and `GET /api/personality/experiences`.
- Injects persona and recent verified status outcomes at the common Hermes adapter boundary, for manual and autonomous executions. No VM permissions or frontend room mechanics are modified.

## Install
Stop backend and frontend. Back up your installation and SQLite database, then unzip with working directory `~/Apps/hermes-life`. Restart backend, then frontend. Refresh browser hard.

Notes: this is *bounded experiential continuity*, not automatic rewrite of core personality and not self-learning model weights. Outcomes are limited to completed/failed status. Schema initialization runs in the app startup lifespan. Historical `agent_personality` table is preserved but no longer used. No model-generated memories or introspection are fabricated.
