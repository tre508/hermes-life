"""Persisted identity and deterministic narration for Hermes Life."""
import json

TEMPERAMENTS = {'curious', 'methodical', 'playful', 'calm', 'reflective', 'cautious'}


def get_profile(store):
    with store.lock:
        row = store.connection.execute('SELECT name,temperament,traits FROM personality WHERE id=1').fetchone()
        if row is None:
            return {'name': 'Hermes', 'temperament': 'curious', 'traits': {}}
        return {'name': row['name'], 'temperament': row['temperament'], 'traits': json.loads(row['traits'])}


def update_profile(store, name, temperament):
    name = name.strip()
    if not 1 <= len(name) <= 40 or any(ord(ch) < 32 for ch in name):
        raise ValueError('Name must contain 1–40 printable characters')
    if temperament not in TEMPERAMENTS:
        raise ValueError('Unsupported temperament')
    with store.lock:
        store.connection.execute('UPDATE personality SET name=?,temperament=? WHERE id=1', (name, temperament))
        store.connection.commit()
    store.emit('personality.updated', {'name': name, 'temperament': temperament})
    return get_profile(store)


def instructions(profile):
    modes = {
        'curious':'Explore relevant alternatives when the task permits, and distinguish verified facts from hypotheses.',
        'methodical':'Use systematic steps and report concrete verification.',
        'playful':'Use a lightly playful communication style without compromising technical precision.',
        'calm':'Keep language concise and steady, including during errors.',
        'reflective':'Summarize what was learned and what remains uncertain.',
        'cautious':'Prefer reversible actions and explicitly verify before concluding.'
    }
    return (f"Agent identity: {profile['name']}. Communication and work-style preference: "
            f"{modes[profile['temperament']]} This preference does not supersede task requirements, "
            "tool permissions, tests, or system instructions.\n\n")


def narrate(event_type, payload, name):
    """Only claim what the observed event supports."""
    if event_type == 'task.queued': return 'planning', 'Focused', f'{name} has a task queued.'
    if event_type == 'task.started': return 'workshop', 'Focused', f'{name} started working on a task.'
    if event_type == 'hermes.system': return 'library', 'Curious', f'{name} is gathering context.'
    if event_type == 'hermes.tool_use':
        raw=json.dumps(payload,ensure_ascii=False).lower()
        if any(t in raw for t in ('pytest','npm test','ctest','cargo test','unittest')):
            return 'laboratory', 'Analytical', f'{name} is running tests.'
        if any(t in raw for t in ('read_file','web_search','search','cat ','grep ','find ')):
            return 'library', 'Curious', f'{name} is inspecting information.'
        return 'workshop', 'Focused', f'{name} is using a development tool.'
    if event_type == 'hermes.tool_result': return 'laboratory', 'Analytical', f'{name} received a tool result.'
    if event_type == 'task.completed': return 'archive', 'Reflective', f'{name} finished the task and is recording the result.'
    if event_type == 'task.failed': return 'archive', 'Cautious', f'{name} encountered a task failure.'
    if event_type.startswith('goal.'): return 'control', 'Focused', f'{name} is updating a goal.'
    if event_type.startswith('discovery.'): return 'library', 'Curious', f'{name} is recording a discovery.'
    return None
