import sqlite3
from hermes_life.schema import migrate
from hermes_life.store import Store
from hermes_life.personality import get_profile,update_profile,narrate,instructions

def test_personality_persists(tmp_path):
    p=tmp_path/'life.db'
    store=Store(p)
    migrate(store.connection)
    assert get_profile(store)['name']=='Hermes'
    update_profile(store,'Nova','methodical')
    later=Store(p)
    assert get_profile(later)['name']=='Nova'
    assert 'systematic' in instructions(get_profile(later))
    assert later.connection.execute('PRAGMA user_version').fetchone()[0]==4

def test_narration_uses_event_not_invented_progress():
    assert narrate('hermes.tool_use',{'tool':'terminal','command':'pytest -q'},'Nova')[0]=='laboratory'
    assert narrate('task.completed',{},'Nova')[0]=='archive'
    assert narrate('unknown',{},'Nova') is None
