# Hermes Life v0.3.4 — Investigation and planning

This patch adds structured, persistent plans from **completed approved read-only investigation goals**. It is an incremental update to v0.3.3.3 plus the v0.3.3.2 response workspace. It does not replace the SSH bridge, rewrite goal history, or authorize coding.

## Workflow

1. Discover a marker and formulate a goal.
2. Approve the formulation: the current Phase 3.3 workflow creates a read-only investigation goal.
3. Enable the existing autonomous scheduler and allow the goal to complete.
4. Open **Investigation plans** and click **Create evidence-backed plan** for the completed approved investigation.
5. Inspect the saved plan: summary, reported evidence, unknowns, implementation steps, acceptance criteria, and risks.

The planning step consumes the **stored task response** as source material. It does not independently verify the report and may contain unverified claims. No code changes are permitted by the planning instructions, but this is prompt-level guidance, not a hard tool-execution sandbox; review recorded tool events when testing.

## New API

- `GET /api/investigation-plans`
- `POST /api/investigation-plans/from-formulation/{formulation_id}`

Returns HTTP 409 if the formulation was not approved, its read-only goal isn't completed, or a plan already exists. Plan generation uses the existing single-agent lock and SSH adapter.

## Storage

`PRAGMA user_version` migrates **1 -> 2** and adds `investigation_plans`. Existing tasks, goals, discoveries, and histories are unchanged. Back up the live SQLite database while backend is stopped before installing.

## Install on Kubuntu host

1. Pause autonomy and stop backend and frontend.
2. Back up `~/Apps/hermes-life` and the SQLite DB (using SQLite backup API or with all writers stopped, copy the db and any WAL).
3. Extract the ZIP into `~/Apps/hermes-life` with `unzip -o ~/Downloads/hermes-life-phase3.4-investigation-patch.zip`.
4. Run `./.venv/bin/python -m pytest -q` with backend stopped.
5. Start backend with `source config/hermes-life-ssh.env.example && ./start.sh`, then frontend with `./scripts/start-world.sh`.
6. Refresh browser with Ctrl+Shift+R and open **Investigation plans**.

## Verification status

- Python backend suite: 19 passed in patch construction environment.
- Frontend browser build: not verified in patch construction environment.
- VM execution: needs validation on your Kubuntu installation.

## Important limits

- Plan creation is user-triggered, not continuously scheduled.
- The read-only investigation is the already-existing approved goal; Phase 3.4 does not duplicate it.
- Plans are recommendations, not demonstrated correctness or permission to implement them.
