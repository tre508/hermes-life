# Hermes Life Phase 4.4 — World-first layout

**Purpose:** Remove the permanent bottom Response & Evidence duplicate; add an Evidence tab beside the existing operations views, while making the world viewport the primary area.

## Install

From the Hermes Life project root:

```bash
unzip -o ~/Downloads/hermes-life-phase4.4-world-layout.zip
python3 scripts/install-phase44-world-layout.py
```

Restart Vite (`./scripts/start-world.sh`) and hard-refresh the browser.

## Notes

- Moves the existing live `#response-workspace` element, so Answer / Tool activity / History / Copy / Expand and their event listeners remain intact.
- Adds one new `Evidence` operations tab. Existing tab handling remains unchanged.
- Retains the floating chat panel, Hermes task execution, WebSockets, backend, SQLite and Obsidian integration unchanged.
- CSS desktop layout provides a larger, flexible world panel and no separate bottom response area.
- The installer backs up `main.ts` and is idempotent.
