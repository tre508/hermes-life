# Hermes Life Phase 3.8 — Evidence-backed reflective memory

**Patch over Phase 3.7 fixed-persona**. Does not change frontend, VM permissions, network isolation, goals or existing database rows.

## What changes
- Schema v6 creates `reflective_runs` containing task-keyword fingerprints, outcome, bounded event type counts, and process lessons. All changes are additive.
- Execution adapter captures evidence for both successful runs and exceptions. No raw terminal output, user prompts or file contents are embedded as instructions in future tasks.
- The next task gets up to three relevant lessons only when there is meaningful vocabulary overlap. Repeated related failures promote a change-of-approach nudge; related successes promote reuse with verification.
- `GET /api/reflections` returns counts and a recent history; existing `/api/personality/experiences` remains available.
- No external model call is made to extract lessons. The current version learns constrained *process habits*, not specific code solutions or an unverified causal diagnosis.

## Install
Stop backend, back up project and SQLite data, unzip at repository root, restart backend. Initial migration runs on app startup.

```
cd ~/Apps/hermes-life
cp -a . "../hermes-life-backup-$(date +%Y%m%d-%H%M%S)"
unzip -o ~/Downloads/hermes-life-phase3.8-reflective-memory.zip
source config/hermes-life-ssh.env.example
./start.sh
```

Validate with `curl -s http://127.0.0.1:8766/api/reflections`.

## Notes
This does not add free-form self-rewriting instructions, project modifications, autonomous permission changes, or a hosted memory service. The safety boundary is intentionally fixed: learned suggestions are lower priority than the real current task.
