import sqlite3
import asyncio
import os
import threading
from pathlib import Path
from contextlib import asynccontextmanager
from .schema import migrate, recover_interrupted
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field
from .store import Store
from .hermes_adapter import HermesAdapter
from .world import sync_world
from .autonomy import Autonomy
from .discovery import Discovery
from .decision import DecisionEngine
from .formulation import GoalFormulator
from .investigation import InvestigationPlanner
from .implementation import ImplementationEngine
from .personality import Personality, PersonalityAdapter
from .knowledge_library import KnowledgeLibrary, KnowledgeAdapter

class GoalInput(BaseModel):
    title: str = Field(min_length=1, max_length=160)
    prompt: str = Field(min_length=1, max_length=20000)
    priority: int = Field(default=50, ge=0, le=100)

class AutonomyInput(BaseModel):
    enabled: bool

class TaskInput(BaseModel):
    prompt: str = Field(min_length=1, max_length=20000)

class Runtime:
    def __init__(self, database, adapter=None):
        self.store = Store(database)
        self.personality = Personality(self.store)
        self.knowledge_library = KnowledgeLibrary(self.store)
        self.adapter = KnowledgeAdapter(PersonalityAdapter(adapter or HermesAdapter(timeout_seconds=int(os.getenv('HERMES_LIFE_TIMEOUT','1800'))), self.personality), self.knowledge_library)
        self.active = threading.Lock()

    def run_task(self, ident):
        try:
            self.store.update_task(ident, 'running')
            self.store.set_agent('executing',ident)
            self.store.emit('task.started', {}, ident)
            def on_event(name, payload):
                self.store.emit(name, payload, ident)
            result = self.adapter.run(self.store.task(ident)['prompt'], on_event)
            self.store.update_task(ident, 'completed', **result)
            self.store.emit('task.completed', {'session_id':result.get('session_id')},ident)
        except Exception as exc:
            self.store.update_task(ident, 'failed', error=str(exc))
            self.store.emit('task.failed', {'error':str(exc)},ident)
        finally:
            self.store.set_agent('idle')
            self.active.release()


def create_app(database=None, adapter=None):
    path = database or os.getenv('HERMES_LIFE_DB', str(Path.home() / '.local/share/hermes-life/life.db'))
    runtime = Runtime(path,adapter)
    autonomy = Autonomy(runtime)
    discovery = Discovery(runtime, autonomy)
    decision = DecisionEngine(runtime, autonomy, discovery)
    formulation = GoalFormulator(runtime, autonomy, discovery)
    planner = InvestigationPlanner(runtime, autonomy, formulation)
    implementer = ImplementationEngine(runtime, planner)
    @asynccontextmanager
    async def lifespan(app):
        with runtime.store.lock:
            migrate(runtime.store.connection)
            runtime.knowledge_library.migrate()
            recover_interrupted(runtime.store.connection)
        autonomy.start()
        decision.start()
        try:
            yield
        finally:
            decision.stop()
            autonomy.stop()

    app = FastAPI(title='Hermes Life', version='0.3.8', lifespan=lifespan)
    app.state.runtime = runtime
    app.state.autonomy = autonomy
    app.state.discovery = discovery
    app.state.decision = decision
    app.state.formulation = formulation
    app.state.investigation_planner = planner
    app.state.implementer = implementer

    @app.get('/api/personality')
    def get_personality():
        return runtime.personality.get()

    @app.get('/api/reflections')
    def reflections():
        return {'stats':runtime.personality.reflection.stats(),
                'recent':[dict(r) for r in runtime.personality.experiences(10)]}

    @app.get('/api/library/sources')
    def library_sources():
        return {'sources': runtime.knowledge_library.sources()}

    @app.post('/api/library/sources')
    def library_register(payload: dict):
        try:
            return runtime.knowledge_library.register(payload.get('url'), payload.get('title'),
                payload.get('kind','pdf'), payload.get('revision',''), payload.get('sha256',''))
        except (ValueError,TypeError) as exc:
            raise HTTPException(422, str(exc))

    @app.post('/api/library/sources/{source_id}/pages')
    def library_pages(source_id: int, payload: dict):
        try:
            return runtime.knowledge_library.add_pages(source_id, payload.get('pages'))
        except (ValueError,TypeError) as exc:
            raise HTTPException(422, str(exc))

    @app.get('/api/library/search')
    def library_search(q: str, limit: int=5):
        return {'matches':runtime.knowledge_library.search(q,limit)}

    @app.get('/api/technical-lessons')
    def technical_lessons(limit: int = 30):
        records = runtime.personality.technical_memory.list(limit)
        return {'total_returned': len(records), 'lessons': records}

    @app.get('/api/technical-lessons/{lesson_id}/challenges')
    def technical_lesson_challenges(lesson_id: int):
        return runtime.personality.technical_memory.challenge_history(lesson_id)

    @app.post('/api/technical-lessons/{lesson_id}/resolve')
    def resolve_technical_lesson(lesson_id: int, payload: dict):
        try:
            return runtime.personality.technical_memory.resolve(
                lesson_id, payload.get('verdict'), payload.get('rationale'),
                payload.get('verification_run_id'), payload.get('verification_excerpt'))
        except (ValueError, TypeError, sqlite3.IntegrityError) as exc:
            raise HTTPException(409, str(exc))

    @app.get('/api/personality/experiences')
    def personality_experiences():
        return [{'state':state,'note':note,'created_at':created_at}
                for state,note,created_at in runtime.personality.experiences(10)]

    @app.get("/api/autonomy")
    def autonomy_state():
        return autonomy.settings()

    @app.put("/api/autonomy")
    def autonomy_control(payload: AutonomyInput):
        return autonomy.enable(payload.enabled)

    @app.get('/api/discoveries')
    def list_discoveries():
        return discovery.list()

    @app.post('/api/discoveries/scan')
    def scan_discoveries():
        try: return discovery.scan()
        except (ValueError,RuntimeError) as exc: raise HTTPException(409,str(exc))

    @app.post('/api/discoveries/{ident}/{action}')
    def decide_discovery(ident: str, action: str):
        try: item = discovery.transition(ident,action)
        except ValueError as exc: raise HTTPException(409,str(exc))
        if item is None: raise HTTPException(404,'Discovery not found')
        return item

    class DecisionInput(BaseModel):
        enabled: bool
        scan_interval_seconds: int = Field(default=3600, ge=60, le=86400)

    @app.get('/api/decisions')
    def decision_status():
        return decision.settings()

    @app.put('/api/decisions')
    def decision_control(payload: DecisionInput):
        return decision.configure(payload.enabled,payload.scan_interval_seconds)

    @app.post('/api/decisions/scan')
    def decision_scan():
        try: return decision.tick(force=True)
        except (ValueError,RuntimeError) as exc: raise HTTPException(409,str(exc))

    @app.get('/api/curiosity')
    def curiosity_queue():
        return decision.curiosity()

    @app.post('/api/curiosity/{ident}/{state}')
    def curiosity_change(ident: str,state: str):
        try: result=decision.set_curiosity_state(ident,state)
        except ValueError as exc: raise HTTPException(400,str(exc))
        if result is None: raise HTTPException(404,'Question not found')
        return result

    @app.get('/api/formulations')
    def list_formulations():
        return formulation.list()

    @app.post('/api/formulations/from-discovery/{discovery_id}', status_code=201)
    def generate_formulation(discovery_id: str):
        try: return formulation.formulate(discovery_id)
        except KeyError as exc: raise HTTPException(404,str(exc))
        except (ValueError,RuntimeError) as exc: raise HTTPException(409,str(exc))
        except Exception as exc: raise HTTPException(422,'Invalid Hermes proposal: '+str(exc)[:240])

    @app.post('/api/formulations/{ident}/{action}')
    def decide_formulation(ident: str, action: str):
        try: item=formulation.transition(ident,action)
        except ValueError as exc: raise HTTPException(409,str(exc))
        if item is None: raise HTTPException(404,'Proposal not found')
        return item

    @app.get('/api/investigation-plans')
    def investigation_plans():
        return planner.list()

    @app.post('/api/investigation-plans/from-formulation/{formulation_id}', status_code=201)
    def create_investigation_plan(formulation_id: str):
        try: return planner.plan(formulation_id)
        except KeyError as exc: raise HTTPException(404,str(exc))
        except (ValueError,RuntimeError) as exc: raise HTTPException(409,str(exc))
        except Exception as exc: raise HTTPException(422,'Invalid plan: '+str(exc)[:240])

    class ImplementationInput(BaseModel):
        project: str = Field(min_length=1, max_length=80)

    @app.get('/api/implementations')
    def implementations():
        return implementer.list()

    @app.get('/api/implementations/{ident}')
    def implementation(ident: str):
        value=implementer.get(ident)
        if not value: raise HTTPException(404,'Implementation not found')
        return value

    @app.post('/api/implementations/from-plan/{plan_id}', status_code=201)
    def start_implementation(plan_id: str, payload: ImplementationInput):
        try: return implementer.start(plan_id,payload.project)
        except KeyError as exc: raise HTTPException(404,str(exc))
        except (ValueError,RuntimeError) as exc: raise HTTPException(409,str(exc))

    @app.get("/api/goals")
    def list_goals():
        return autonomy.list()

    @app.post("/api/goals", status_code=201)
    def add_goal(payload:GoalInput):
        return autonomy.add(payload.title,payload.prompt,payload.priority)

    @app.post("/api/goals/{goal_id}/cancel")
    def cancel_goal(goal_id:str):
        try: value=autonomy.cancel(goal_id)
        except ValueError as exc: raise HTTPException(409,str(exc))
        if not value:raise HTTPException(404,"Goal not found")
        return value

    @app.post("/api/goals/{goal_id}/retry")
    def retry_goal(goal_id:str):
        try: value=autonomy.retry(goal_id)
        except ValueError as exc: raise HTTPException(409,str(exc))
        if not value:raise HTTPException(404,"Goal not found")
        return value

    @app.get('/health')
    def health():
        return {'status':'ok','hermes_available':runtime.adapter.available()}

    @app.get('/api/world/state')
    def world_state():
        return sync_world(runtime.store)

    @app.get('/api/agent/state')
    def state():
        return runtime.store.agent()

    @app.get('/api/tasks')
    def tasks():
        return runtime.store.tasks()

    @app.get('/api/tasks/{task_id}')
    def get_task(task_id: str):
        task = runtime.store.task(task_id)
        if not task:
            raise HTTPException(404, 'Task not found')
        return task

    @app.post('/api/tasks', status_code=202)
    def create_task(payload: TaskInput):
        if not runtime.adapter.available():
            raise HTTPException(503, 'Hermes CLI unavailable')
        if not runtime.active.acquire(blocking=False):
            raise HTTPException(409, 'Agent is busy')
        try:
            task = runtime.store.create_task(payload.prompt)
            runtime.store.emit('task.queued', {'task_id':task['id']},task['id'])
            threading.Thread(target=runtime.run_task,args=(task['id'],),daemon=True).start()
            return task
        except Exception:
            runtime.active.release()
            raise

    @app.get('/api/events')
    def events(after: int=0, limit: int=200):
        return runtime.store.events(after,limit)

    @app.websocket('/ws/events')
    async def ws_events(websocket: WebSocket):
        await websocket.accept()
        try:
            after = max(0,int(websocket.query_params.get('after','0')))
            while True:
                sync_world(runtime.store)
                batch = runtime.store.events(after)
                for event in batch:
                    await websocket.send_json(event)
                    after = event['sequence']
                await asyncio.sleep(0.4)
        except (WebSocketDisconnect, RuntimeError):
            pass

    return app

