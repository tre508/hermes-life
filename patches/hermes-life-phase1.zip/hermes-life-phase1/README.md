# Hermes Life — Phase 1 Foundation

A minimal, runnable local FastAPI backend that connects to the installed Hermes CLI, stores tasks and tool events in SQLite and exposes a WebSocket stream for a future pixel-art frontend.

## Kubuntu install

```bash
mkdir -p /home/gayzer/Apps/hermes-life
# Extract the ZIP's contents into that directory
cd /home/gayzer/Apps/hermes-life
./start.sh
```

Open http://127.0.0.1:8766/docs to explore and submit tasks through the API. Do not expose this development server publicly; no authentication is implemented in Phase 1.

## Smoke test

```bash
curl http://127.0.0.1:8766/health
curl -X POST http://127.0.0.1:8766/api/tasks -H 'Content-Type: application/json' -d '{"prompt":"Reply with the word ready"}'
curl http://127.0.0.1:8766/api/tasks
curl http://127.0.0.1:8766/api/events
```

## Automated tests

```bash
. .venv/bin/activate
pytest -q
```

## Hermes integration

Uses `hermes chat --query-file <temporary file> --format stream-json`, as documented by the official Hermes CLI. Does not edit existing Hermes config. Hermes runs under the account and configured tool permissions of the user launching the server. Verify the installed Hermes version supports `--format stream-json` with `hermes chat --help`.

## Phase 1 limitations

- One active task at a time, explicitly submitted; autonomous discovery/selection comes later.
- Durable tasks and events, but active tasks are marked interrupted on restart; no automatic replay.
- CLI stream event handling; no cancellation or backpressure management yet.
- Local API has no authentication. It binds to 127.0.0.1 only.
- WebSocket is polling the event store for new events; no UI yet.
- The timeout is evaluated when the stream yields another line; a completely silent stalled process may not be terminated at the configured timeout. Worker watchdog comes in phase 2.
- This adapter invokes Hermes in its existing profile. Dedicated profile isolation should be verified and added before autonomous operation.
