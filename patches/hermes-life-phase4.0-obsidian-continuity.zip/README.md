# Hermes Life Phase 4.0 — Obsidian conversation continuity

Vault: `/home/gayzer/black/obsidian/hermes/`

This is a conservative first stage of Phase 4.0: stable conversation IDs, ordered previous-turn context, host SQLite persistence, and Markdown mirroring to `Hermes-Life/Conversations/` within your existing vault. It does not overwrite other notes and does not claim autonomous summarization of the entire vault.

## Install

Stop the Hermes Life backend and frontend. From your Kubuntu host:

```bash
cd ~/Apps/hermes-life
unzip -o ~/Downloads/hermes-life-phase4.0-obsidian-continuity.zip
python3 scripts/install-phase40.py
export HERMES_LIFE_OBSIDIAN_VAULT=/home/gayzer/black/obsidian/hermes/
source config/hermes-life-ssh.env.example
./start.sh
```

In the other terminal, restart `./scripts/start-world.sh` and hard-refresh your browser.

The installer backs up the modified app.py and main.ts before modifying them. Existing tasks and technical memories are not deleted. All new conversation records are added to the host SQLite database. Notes mirror into `<vault>/Hermes-Life/Conversations/<conversation-id>.md` only when the vault directory exists. If unavailable, SQLite still records the turns.

## Verify

Submit a task (e.g. “Explain the difference between tuples and lists in two sentences.”). Then ask “Give me an example of the second one.” Results should use the earlier turn. Check:

```bash
curl -sS http://127.0.0.1:8766/api/conversations | python3 -m json.tool
find /home/gayzer/black/obsidian/hermes/Hermes-Life/Conversations -name '*.md' -maxdepth 1
```

To start a new conversation rather than continue the same thread, in the browser DevTools console run:

```js
localStorage.removeItem('hermes-life-conversation-id'); location.reload();
```

## Limits

The last 12 turns are used for task context (up to 2,400 characters per turn); all turns remain in SQLite and the Obsidian mirror. The vault is not yet searchable or automatically summarized for cross-conversation retrieval. Tasks submitted by the autonomous goal scheduler retain their existing behavior. Frontend thread identity is stored per browser origin; another browser creates a new conversation. The server considers the vault path trusted local configuration; don't expose the API publicly.
