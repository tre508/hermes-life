# Hermes Life Phase 3.10.1 — Bridge Visual Polish

Frontend-only patch based on Phase 3.10. Replaces `frontend/src/main.ts` and `frontend/src/style.css`.

Adds: animated console indicator lights, deck lines and trim, a larger/more legible animated robot, hover feedback on all six stations, and an in-world line narrating the activity supplied by the existing backend world state. The frontend version pill becomes `WORLD / 0.3.11` at startup. No new backend calls, artificial task events, or altered VM connectivity.

## Install
Stop only the frontend server. From the Hermes Life project root, back up frontend/src, then extract this ZIP and restart `./scripts/start-world.sh`. Hard-refresh the browser.

## Verification
- Clicking each of six stations should still open the room details panel.
- Switching backend activity should update the robot destination and in-world narration.
- Idle animation/console blink are graphical only, not claimed events.
- TypeScript syntax/transpilation was checked locally; full Vite build could not complete in the offline environment due to unavailable npm dependencies.
