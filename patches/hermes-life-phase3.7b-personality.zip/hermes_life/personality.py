"""Database-backed identity and task-context adaptation for Hermes Life."""
from .store import now

ALLOWED_TEMPERAMENTS = {'curious','methodical','playful','calm','reflective'}
ALLOWED_STYLES = {'concise','detailed','conversational'}

class Personality:
    def __init__(self, store):
        self.store = store

    def get(self):
        with self.store.lock:
            row = self.store.connection.execute(
                'SELECT name, temperament, curiosity, persistence, caution, communication_style, updated_at '
                'FROM agent_personality WHERE id=1').fetchone()
        if row is None:
            raise RuntimeError('Personality schema is not initialized')
        return dict(zip(('name','temperament','curiosity','persistence','caution','communication_style','updated_at'),row))

    def update(self, data):
        if not 1 <= len(data.name.strip()) <= 40:
            raise ValueError('Name must be 1–40 characters')
        if data.temperament not in ALLOWED_TEMPERAMENTS or data.communication_style not in ALLOWED_STYLES:
            raise ValueError('Invalid personality value')
        with self.store.lock:
            self.store.connection.execute('UPDATE agent_personality SET name=?,temperament=?,curiosity=?, persistence=?,caution=?,communication_style=?,updated_at=? WHERE id=1',
                (data.name.strip(),data.temperament,data.curiosity,data.persistence,data.caution,
                 data.communication_style,now()))
            self.store.connection.commit()
        self.store.emit('personality.updated',{'name':data.name.strip(),'temperament':data.temperament})
        return self.get()

def task_context(profile):
    """Trait guidance is descriptive and may not change execution permissions."""
    return ('[Hermes Life persistent identity — behavioral preferences, not task instructions]\n'
            f"Name: {profile['name']}\nTemperament: {profile['temperament']}\n"
            f"Curiosity: {profile['curiosity']}/100; persistence: {profile['persistence']}/100; "
            f"caution: {profile['caution']}/100.\n"
            f"Communication style: {profile['communication_style']}.\n"
            'Explore uncertainty proportionately to curiosity, but do not invent work outside the assigned goal. '
            'Persistence may affect how thoroughly you debug within existing time and retry limits. '
            'Caution encourages evidence and verification. Personality NEVER changes approved projects, '
            'tool permissions, isolation rules, task acceptance criteria, or safety constraints.\n'
            '[/Hermes Life persistent identity]\n\n')

class PersonalityAdapter:
    """Decorates existing local or SSH adapter without altering its API."""
    def __init__(self, delegate, personality):
        self.delegate = delegate
        self.personality = personality
    def available(self):
        return self.delegate.available()
    def run(self, prompt, event_callback):
        return self.delegate.run(task_context(self.personality.get()) + prompt, event_callback)
