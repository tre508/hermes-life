"""Explicit, versioned schema setup and single-owner restart recovery."""
from .store import now

SCHEMA_VERSION = 3
DDL = r'''

            CREATE TABLE IF NOT EXISTS tasks (
                id TEXT PRIMARY KEY, prompt TEXT NOT NULL, state TEXT NOT NULL,
                created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                result TEXT, error TEXT, session_id TEXT
            );
            CREATE TABLE IF NOT EXISTS events (
                sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                id TEXT NOT NULL UNIQUE, task_id TEXT,
                type TEXT NOT NULL, timestamp TEXT NOT NULL, payload TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS agent_state (
                id INTEGER PRIMARY KEY CHECK(id=1), state TEXT NOT NULL,
                current_task TEXT, updated_at TEXT NOT NULL
            );
            INSERT OR IGNORE INTO agent_state VALUES (1, 'idle', NULL, '');
            CREATE TABLE IF NOT EXISTS world_state (
                id INTEGER PRIMARY KEY CHECK(id=1),
                room TEXT NOT NULL, activity TEXT NOT NULL,
                agent_x INTEGER NOT NULL, agent_y INTEGER NOT NULL,
                last_sequence INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL
            );
            INSERT OR IGNORE INTO world_state VALUES
                (1, 'rest', 'idle', 0, 0, 0, '');
            

                CREATE TABLE IF NOT EXISTS autonomy_settings (
                  id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 0
                );
                INSERT OR IGNORE INTO autonomy_settings(id,enabled) VALUES(1,0);
                CREATE TABLE IF NOT EXISTS goals (
                  id TEXT PRIMARY KEY, title TEXT NOT NULL, prompt TEXT NOT NULL,
                  state TEXT NOT NULL, priority INTEGER NOT NULL, created_at TEXT NOT NULL,
                  updated_at TEXT NOT NULL, task_id TEXT, error TEXT
                );
            

    CREATE TABLE IF NOT EXISTS discoveries (
     id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL UNIQUE,
     project TEXT NOT NULL, path TEXT NOT NULL, line INTEGER NOT NULL,
     note TEXT NOT NULL, proposed_prompt TEXT NOT NULL,
     rationale TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'proposed',
     created_at TEXT NOT NULL, updated_at TEXT NOT NULL, goal_id TEXT
    );
   

    CREATE TABLE IF NOT EXISTS decision_settings (
      id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 0,
      scan_interval_seconds INTEGER NOT NULL DEFAULT 3600, last_scan TEXT,
      last_error TEXT
    );
    INSERT OR IGNORE INTO decision_settings(id,enabled) VALUES (1,0);
    CREATE TABLE IF NOT EXISTS curiosity (
      id TEXT PRIMARY KEY, discovery_id TEXT NOT NULL UNIQUE, question TEXT NOT NULL,
      category TEXT NOT NULL, priority INTEGER NOT NULL, state TEXT NOT NULL,
      rationale TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
   

                CREATE TABLE IF NOT EXISTS formulated_goals (
                  id TEXT PRIMARY KEY, discovery_id TEXT NOT NULL UNIQUE,
                  title TEXT NOT NULL, action TEXT NOT NULL,
                  rationale TEXT NOT NULL, acceptance TEXT NOT NULL,
                  prompt TEXT NOT NULL, priority INTEGER NOT NULL,
                  state TEXT NOT NULL, goal_id TEXT,
                  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
                );
            
'''

def migrate(connection):
    version = connection.execute('PRAGMA user_version').fetchone()[0]
    if version > SCHEMA_VERSION:
        raise RuntimeError(f'Database schema {version} is newer than supported {SCHEMA_VERSION}')
    if version < 1:
        connection.executescript(DDL)
        connection.execute('PRAGMA user_version=1')
        connection.commit()
    if version < 2:
        _upgrade_to_v2(connection)
    if version < 3:
        _upgrade_to_v3(connection)

def _upgrade_to_v2(connection):
    connection.execute("""CREATE TABLE IF NOT EXISTS investigation_plans (
      id TEXT PRIMARY KEY, formulation_id TEXT NOT NULL UNIQUE,
      task_id TEXT NOT NULL, report TEXT NOT NULL, created_at TEXT NOT NULL
    )""")
    connection.execute('PRAGMA user_version=2')
    connection.commit()

def _upgrade_to_v3(connection):
    connection.execute("""CREATE TABLE IF NOT EXISTS implementation_runs (
      id TEXT PRIMARY KEY, plan_id TEXT NOT NULL UNIQUE, project TEXT NOT NULL,
      state TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
      candidate_path TEXT, baseline_path TEXT, baseline_json TEXT,
      candidate_json TEXT, response TEXT, error TEXT
    )""")
    connection.execute('PRAGMA user_version=3')
    connection.commit()

def recover_interrupted(connection):
    stamp = now()
    connection.execute("UPDATE tasks SET state='interrupted', updated_at=? WHERE state IN ('running','queued')", (stamp,))
    connection.execute("UPDATE goals SET state='interrupted', updated_at=? WHERE state='running'", (stamp,))
    connection.execute("UPDATE agent_state SET state='idle', current_task=NULL, updated_at=? WHERE id=1", (stamp,))
    connection.commit()
