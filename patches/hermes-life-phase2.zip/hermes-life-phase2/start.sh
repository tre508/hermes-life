#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -d .venv ]]; then
  python3 -m venv .venv
fi
. .venv/bin/activate
pip install -e '.[test]'
exec uvicorn hermes_life.app:app --host 127.0.0.1 --port 8766
