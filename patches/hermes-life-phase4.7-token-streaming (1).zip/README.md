# Hermes Life Phase 4.7 — Genuine response streaming

The existing `hermes chat --format stream-json` CLI produces `type=text` JSONL records for assistant text deltas, but the Hermes Life adapter filtered them out. This patch passes those real deltas through the existing task-scoped event store and `/ws/events` WebSocket and updates one in-progress Hermes chat bubble. No fake word-by-word playback, no private reasoning.

## Install

From `~/Apps/hermes-life`:

```bash
unzip -o ~/Downloads/hermes-life-phase4.7-token-streaming.zip
python3 scripts/install-phase47-token-streaming.py
```

Restart **both backend and frontend**, ensuring the SSH transport env and Obsidian vault env are loaded as before. Refresh browser. Send a new task through Chat and observe the Hermes reply appear progressively. The final answer is still stored by the existing conversation completion code, not by delta events. Existing events are replayed by WebSocket `after` sequence where supported.

This does not implement stop/pause or private chain-of-thought streaming. For long tool runs, text appears only when Hermes actually emits `text` events. `result.replay_gap` can indicate missing intermediate tokens while final output remains complete.
