# Hermes Life Phase 4.3 — Cross-thread recall and linked edits

This is an incremental, conservative backend patch for the running Phase 4.0–4.2 installation.

## Included
- Existing SQLite conversation history becomes available across conversations through capped lexical relevance retrieval. Retrieval is separated from instructions, excludes the active conversation, and never loads the entire vault into the prompt.
- Explicit, curated long-term memories with `GET /api/memories` and `POST /api/memories`. Corrections can supersede outdated memories by specifying `supersedes` (the old row is retained with `status=superseded` and excluded from retrieval).
- Stable turn IDs returned in conversation history, linked revisions recorded in `hl_turn_revisions`, with original content preserved. The chat's **Edit & rerun** prepares a new instruction and sends the revision linkage only when the user explicitly presses Send.
- An opt-in **Remember** action on user turns. The user can edit the extracted note before it is stored.
- Keeps the Phase 4.2 theme and Phase 4.0 Obsidian mirror. No direct changes to the VM adapter, persona, or earlier technical lessons.

## Install

Stop backend/frontend, then run in the Hermes Life root:

```bash
unzip -o /path/to/hermes-life-phase4.3-recall-and-revisions.zip
python3 scripts/install-phase43.py
source config/hermes-life-ssh.env.example
export HERMES_LIFE_OBSIDIAN_VAULT=/home/gayzer/black/obsidian/hermes/
./start.sh
```

Restart frontend in another terminal with `./scripts/start-world.sh`, then hard-refresh.

## Verify

```bash
curl -fsS http://127.0.0.1:8766/api/memories
```

In chat: submit a message; use **Remember** on the user bubble; check `/api/memories`; open another conversation and ask a question using at least two meaningful terms from the saved memory. Use **Edit & rerun** on a prior turn, review the prepared correction and explicitly submit it; verify `/api/conversations/<id>/revisions`.

## Precisely scoped limitations

- This is lexical text matching, not semantic embedding retrieval; only memories with overlapping terms are recalled. No automatic LLM memory extraction yet (intentional to avoid storing unsupported statements).
- Revisions preserve original content and provenance but are **not full branch snapshots**. Editing does not roll back completed external effects or downstream task history. A new explicit task is submitted, and the original turn is excluded from later prompt context where supported.
- No token deltas are emitted by the current verified adapter. WebSocket execution **events** still work, but final answer text arrives at task completion.
- No safe runtime suspend, resume, or cancellation API has been verified in the current adapter. This patch does **not** expose deceptive Pause/Resume/Stop controls.
